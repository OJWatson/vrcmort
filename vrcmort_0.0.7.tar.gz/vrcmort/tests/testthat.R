library(testthat)
library(vrcmort)

test_check("vrcmort")
