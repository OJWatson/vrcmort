## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## -----------------------------------------------------------------------------
library(vrcmort)

base <- vrc_simulate(R = 5, T = 48, t0 = 20, seed = 1, missing = list(type = "none"))
block <- vrc_simulate(R = 5, T = 48, t0 = 20, seed = 1, missing = list(type = "block", block_intercept = -1.5))
age <- vrc_simulate(R = 5, T = 48, t0 = 20, seed = 1, missing = list(type = "age_selective", age_dropout_strength = 1.0, age_dropout_old_from = 6))
combo <- vrc_simulate(R = 5, T = 48, t0 = 20, seed = 1, missing = list(type = "combined", block_intercept = -2.0, age_dropout_strength = 1.0, mnar_strength = 1.0))

c(
  base = mean(is.na(base$df_full$y)),
  block = mean(is.na(block$df_full$y)),
  age = mean(is.na(age$df_full$y)),
  combo = mean(is.na(combo$df_full$y))
)

## ----eval=FALSE---------------------------------------------------------------
# fit <- vrc_fit(
#   data = combo$df_obs,
#   t0 = combo$meta$t0,
#   mortality_covariates = ~ facility,
#   reporting_covariates = ~ facility,
#   chains = 4,
#   iter = 1000,
#   seed = 1
# )
# 
# plot_reporting(fit)
# plot_mortality(fit, value = "true_deaths")

