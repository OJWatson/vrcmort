## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## -----------------------------------------------------------------------------
library(vrcmort)

sim <- vrc_simulate(
  R = 5,
  T = 60,
  t0 = 25,
  seed = 123,
  missing = list(type = "combined", block_intercept = -2.0, mnar_strength = 1.0)
)

head(sim$df_obs)

## ----eval=FALSE---------------------------------------------------------------
# diag <- vrc_diagnose_reporting(sim$df_obs, t0 = sim$meta$t0)
# diag$tables$totals_time
# 
# diag$plots$by_cause

## ----eval=FALSE---------------------------------------------------------------
# # Basic model: no additional covariates beyond the built-in conflict proxy
# mort <- vrc_mortality(~ 1)
# rep  <- vrc_reporting(~ 1)
# 
# fit <- vrcm(
#   mortality = mort,
#   reporting = rep,
#   data = sim$df_obs,
#   t0 = sim$meta$t0,
#   chains = 4,
#   iter = 1000,
#   seed = 123
# )
# 
# print(fit)

## ----eval=FALSE---------------------------------------------------------------
# mort2 <- vrc_mortality(~ facility + food_insecurity)
# rep2  <- vrc_reporting(~ facility)
# 
# fit2 <- vrcm(
#   mortality = mort2,
#   reporting = rep2,
#   data = sim$df_obs,
#   t0 = sim$meta$t0,
#   chains = 4,
#   iter = 1000,
#   seed = 123
# )
# 
# vrc_coef_summary(fit2)

