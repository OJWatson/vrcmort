## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## -----------------------------------------------------------------------------
library(vrcmort)

sim <- vrc_simulate(R = 5, T = 48, t0 = 20, seed = 1)
vr_long <- sim$df_obs

t0 <- sim$meta$t0

## ----eval=FALSE---------------------------------------------------------------
# fit0 <- vrcm(
#   mortality = vrc_mortality(~ 1),
#   reporting = vrc_reporting(~ 1),
#   data = vr_long,
#   t0 = t0,
#   chains = 4,
#   iter = 1000,
#   seed = 1
# )
# 
# plot(fit0, type = "reporting")
# plot(fit0, type = "mortality", value = "true_deaths")

## ----eval=FALSE---------------------------------------------------------------
# fit1 <- vrcm(
#   mortality = vrc_mortality(~ facility),
#   reporting = vrc_reporting(~ facility),
#   data = vr_long,
#   t0 = t0,
#   chains = 4,
#   iter = 1000,
#   seed = 1
# )
# 
# vrc_coef_summary(fit1)

## ----eval=FALSE---------------------------------------------------------------
# fit2 <- vrcm(
#   mortality = vrc_mortality(~ facility, conflict = "region"),
#   reporting = vrc_reporting(~ facility, conflict = "region"),
#   data = vr_long,
#   t0 = t0,
#   chains = 4,
#   iter = 1000,
#   seed = 1
# )
# 
# # Region-specific conflict effects
# vrc_conflict_effects(fit2, component = "mortality")
# vrc_conflict_effects(fit2, component = "reporting")

## ----eval=FALSE---------------------------------------------------------------
# fit3 <- vrcm(
#   mortality = vrc_mortality(~ facility, conflict = "region", time = "region"),
#   reporting = vrc_reporting(~ facility, conflict = "region", time = "region"),
#   data = vr_long,
#   t0 = t0,
#   chains = 4,
#   iter = 1000,
#   seed = 1
# )

## ----eval=FALSE---------------------------------------------------------------
# pp <- posterior_predict(fit2)
# # Compare distributions of y_rep to observed y

## ----eval=FALSE---------------------------------------------------------------
# library(loo)
# 
# loglik0 <- rstan::extract(fit0$stanfit, pars = "log_lik")$log_lik
# loglik1 <- rstan::extract(fit1$stanfit, pars = "log_lik")$log_lik
# loglik2 <- rstan::extract(fit2$stanfit, pars = "log_lik")$log_lik
# 
# loo0 <- loo(loglik0)
# loo1 <- loo(loglik1)
# loo2 <- loo(loglik2)
# 
# loo_compare(loo0, loo1, loo2)

