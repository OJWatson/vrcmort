## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("figures/model_schematic.png")

