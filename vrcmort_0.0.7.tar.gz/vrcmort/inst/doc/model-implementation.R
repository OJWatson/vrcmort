## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----eval=FALSE---------------------------------------------------------------
# vrc_canonical_columns()

## ----eval=FALSE---------------------------------------------------------------
# vrc_validate_data(vr_long)

## ----eval=FALSE---------------------------------------------------------------
# idx <- vrc_index(vr_long)
# str(idx$meta)

## ----eval=FALSE---------------------------------------------------------------
# mort <- vrc_mortality(~ facility + food_insecurity)
# rep  <- vrc_reporting(~ facility)

## ----eval=FALSE---------------------------------------------------------------
# standata_bundle <- vrcm(
#   mortality = mort,
#   reporting = rep,
#   data = vr_long,
#   t0 = conflict_start_month,
#   chains = 0
# )
# 
# names(standata_bundle$standata)

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   beta_conf = normal(0.3, 0.2),
#   gamma_conf = normal(0, 0.5),
#   beta_mort = normal(0, 0.5, autoscale = TRUE),
#   gamma_rep = normal(0, 0.7, autoscale = TRUE)
# )
# 
# fit <- vrcm(
#   mortality = mort,
#   reporting = rep,
#   data = vr_long,
#   t0 = conflict_start_month,
#   priors = pri,
#   chains = 4,
#   iter = 1000
# )
# 
# vrc_prior_summary(fit)

## ----eval=FALSE---------------------------------------------------------------
# fit <- vrcm(
#   mortality = mort,
#   reporting = rep,
#   data = vr_long,
#   t0 = conflict_start_month,
#   chains = 4,
#   iter = 2000,
#   adapt_delta = 0.95,
#   max_treedepth = 12
# )

