## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----eval=FALSE---------------------------------------------------------------
# library(vrcmort)
# 
# # Region-varying conflict effects and region-specific time trends
# mort_pp <- vrc_mortality(~ facility, conflict = "region", time = "region")
# rep_pp  <- vrc_reporting(~ facility, conflict = "region", time = "region")
# 
# fit_pp <- vrcm(
#   mortality = mort_pp,
#   reporting = rep_pp,
#   data = vr_long,
#   t0 = conflict_start_month,
#   chains = 4,
#   iter = 1000
# )
# 
# # Extract region-specific conflict effects
# vrc_conflict_effects(fit_pp, component = "mortality")
# vrc_conflict_effects(fit_pp, component = "reporting")

