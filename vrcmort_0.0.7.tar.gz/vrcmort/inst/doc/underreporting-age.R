## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("figures/age_underreporting_illustration.png")

## ----eval=FALSE---------------------------------------------------------------
# library(dplyr)
# library(ggplot2)
# 
# vr_long %>%
#   mutate(period = if_else(time < t0, "pre", "post")) %>%
#   group_by(period, age, cause) %>%
#   summarise(y = sum(y, na.rm = TRUE), .groups = "drop") %>%
#   group_by(period, cause) %>%
#   mutate(frac = y / sum(y)) %>%
#   ggplot(aes(x = age, y = frac, group = period)) +
#   geom_line() +
#   facet_wrap(~ cause) +
#   labs(y = "Share of recorded deaths")

## ----eval=FALSE---------------------------------------------------------------
# fit <- vrcm(
#   mortality = vrc_mortality(~ 1),
#   reporting = vrc_reporting(~ 1),
#   data = vr_long,
#   t0 = t0,
#   chains = 4,
#   iter = 1000
# )
# 
# rho <- posterior_reporting(fit)
# 
# # Summarise completeness by age and period
# rho %>%
#   mutate(period = if_else(time < t0, "pre", "post")) %>%
#   group_by(period, cause, age) %>%
#   summarise(rho_mean = mean(rho_mean), .groups = "drop")

