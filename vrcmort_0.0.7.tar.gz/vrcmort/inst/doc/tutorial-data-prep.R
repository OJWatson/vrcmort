## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----eval=FALSE---------------------------------------------------------------
# icd_to_cause <- function(icd10) {
#   icd10 <- toupper(trimws(icd10))
#   # Missing or empty code
#   if (is.na(icd10) || icd10 == "") return(NA_character_)
# 
#   # Very rough trauma proxy: External causes (V-Y) in ICD-10
#   if (grepl("^[VWXY]", icd10)) return("trauma")
# 
#   "non_trauma"
# }

## ----eval=FALSE---------------------------------------------------------------
# cut_age <- function(age_years) {
#   cut(
#     age_years,
#     breaks = c(-Inf, 4, 14, 24, 34, 44, 54, 64, Inf),
#     labels = c("0-4","5-14","15-24","25-34","35-44","45-54","55-64","65+"),
#     right = TRUE
#   )
# }

## ----eval=FALSE---------------------------------------------------------------
# library(dplyr)
# 
# vr_counts <- deaths_individual %>%
#   mutate(
#     time = month_id,  # or convert calendar month to an index
#     age = cut_age(age_years),
#     cause = vapply(icd10, icd_to_cause, character(1)),
#     sex = factor(sex, levels = c("F","M"))
#   ) %>%
#   filter(!is.na(cause), !is.na(age), !is.na(sex)) %>%
#   mutate(cause = if_else(cause == "trauma", "trauma", "non_trauma")) %>%
#   group_by(region, time, age, sex, cause) %>%
#   summarise(y = n(), .groups = "drop")

## ----eval=FALSE---------------------------------------------------------------
# # pop should contain: region, time, age, sex, pop
# vr_long <- vr_counts %>%
#   left_join(pop, by = c("region","time","age","sex")) %>%
#   mutate(exposure = pop)

## ----eval=FALSE---------------------------------------------------------------
# # Suppose coverage_fraction is in [0,1] for each region-month
# vr_long <- vr_long %>%
#   left_join(covariates_rt %>% select(region, time, coverage_fraction), by = c("region","time")) %>%
#   mutate(exposure = pop * coverage_fraction)

## ----eval=FALSE---------------------------------------------------------------
# # covariates_rt should contain: region, time, conflict, facility, etc
# vr_long <- vr_long %>%
#   left_join(covariates_rt, by = c("region","time"))

## ----eval=FALSE---------------------------------------------------------------
# vr_long <- vr_long %>%
#   mutate(
#     region = factor(region),
#     age = factor(age, ordered = TRUE),
#     sex = factor(sex),
#     cause = factor(cause, levels = c("trauma","non_trauma"))
#   )

## ----eval=FALSE---------------------------------------------------------------
# library(vrcmort)
# 
# vrc_validate_data(vr_long)
# 
# diag <- vrc_diagnose_reporting(vr_long, t0 = conflict_start_month)
# diag$plots$by_cause

## ----eval=FALSE---------------------------------------------------------------
# fit <- vrcm(
#   mortality = vrc_mortality(~ 1),
#   reporting = vrc_reporting(~ 1),
#   data = vr_long,
#   t0 = conflict_start_month,
#   chains = 4,
#   iter = 1000
# )
# 
# plot(fit, type = "reporting")
# plot(fit, type = "mortality", value = "true_deaths")

