## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   beta_conf = normal(0.3, 0.2),
#   beta_mort = normal(0, 0.5, autoscale = TRUE),
#   gamma_rep = normal(0, 0.7, autoscale = TRUE),
#   phi = exponential(1)
# )
# 
# fit <- vrcm(
#   mortality = vrc_mortality(~ facility),
#   reporting = vrc_reporting(~ facility),
#   data = vr_long,
#   t0 = conflict_start_month,
#   priors = pri,
#   chains = 4,
#   iter = 1000
# )

## ----eval=FALSE---------------------------------------------------------------
# vrc_prior_summary(fit)

## ----eval=FALSE---------------------------------------------------------------
# # Suppose you believe pre-conflict completeness is around:
# # trauma ~ 0.6, non-trauma ~ 0.9
# pri <- vrc_priors(
#   kappa0 = normal(qlogis(c(0.6, 0.9)), c(0.6, 0.4))
# )

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   beta_conf = normal(0.2, 0.3)
# )

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   gamma_conf = normal(0, 0.5)
# )

## ----eval=FALSE---------------------------------------------------------------
# # More over-dispersion
# pri <- vrc_priors(phi = exponential(2))
# 
# # Less over-dispersion (more Poisson-like)
# pri <- vrc_priors(phi = exponential(0.5))

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   kappa_post = normal(0, 0.3),
#   delta_age_scale = normal(0, 0.5)
# )

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   kappa_post = normal(c(0, -1.5), c(0.5, 0.5)),
#   gamma_conf = normal(c(0, -0.5), c(0.5, 0.5))
# )

## ----eval=FALSE---------------------------------------------------------------
# pri <- vrc_priors(
#   beta_conf = normal(c(0.6, 0.1), c(0.3, 0.2))
# )

